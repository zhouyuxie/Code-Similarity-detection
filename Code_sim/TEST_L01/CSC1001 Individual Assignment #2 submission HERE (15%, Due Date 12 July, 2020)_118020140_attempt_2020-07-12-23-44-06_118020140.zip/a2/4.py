s1=input('The first word:')
s2=input('The second word:')
def isAnagram(s1,s2):
    a=list(s1)
    a.sort()
    b=list(s2)
    b.sort()
    if a==b:
        return 'is an anagram'
    else:
        return 'is not an anagram'
print(isAnagram(s1,s2))
    
