number=2
def isPrime(number): #check if it is a prime number
    divisor=2
    while divisor<=number/2:
        if number%divisor==0:
            return False
        else:
            divisor+=1
            continue
    return True

a=[]                                #creat a list which include enough prime numbers
while number<10000:
        if isPrime(number):
                a.append(number)
                number+=1
        else:
                number+=1
                continue
def reverse(number): #define a function to get the reverse number
    reversenumber=''
    while number != 0:
        reversenumber+=str(number%10)
        number//=10
    reversenumber=int(reversenumber)
    return reversenumber
b=[]                   #b is a list includes the reverse numbers that can be found in the 'a' list. So b is a emirp list.
for i in a:
    if reverse(i) in a and i>10:
        b.append(i)
count=0
for m in b[:100]:#print 100 numbers from b.
    print("%6d"%m,end='')
    count+=1
    if count%10==0:
        print()
