Q1��
 Please type a number n which is larger than 0 and press Enter.
 You will get an approximated square root of n.

Q2:
 Without any operation from users, it will display the first 100 emirps.

Q3:
 Type your card number and press Enter.
 If the card is valid, it will display 'True'. Otherwise, it will display 'invalid'.

Q4:
  Type one word and press Enter. Then type the other word press Enter.
  The program checks whether two words are anagrams. Two words are anagrams if they contain the same letters. For example, silent and listen are anagrams.

Q5:
 This program shows the answer of the locker puzzle which has 100 lockers and 100 students.
 The result indicates which lockers are open.

Q6:
 The program will randomly display a possible solution of eight queen puzzle.
