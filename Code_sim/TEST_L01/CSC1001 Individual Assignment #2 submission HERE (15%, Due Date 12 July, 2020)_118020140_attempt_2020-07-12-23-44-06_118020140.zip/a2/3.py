number=input('Please enter a card number: ')
def isValid(number): #check the digit and the initail number
    if 13<=len(number)<=16:
        if number.startswith('4'):
            return True
        elif number.startswith('5'):
            return True
        elif number.startswith('37'):
            return True
        elif number.startswith('6'):
            return True
        else:
            return False
            print('invalid card')
    else:
        print('invalid card')
        return False

def sumOfDoubleEvenPlace(number):#calculate the sum of even places of the card number
    a=list(number)
    if len(a)==13 or len(a)==15:#this is the occasion of singular digit 
        b=a[1::2]
    else:
        b=a[::2]                 #this is the occasion of even digit 
    c=[eval(i)*2 for i in b]#mutiply 2 
    d=[i%10+1 if i>9 else i for i in c]#replace the twodigit number into a single-digit number
    return sum(d)

def sumOfOddPlace(number):#calculate the sum of odd places of the card number
    a=list(number)
    if len(a)==13 or len(a)==15:
        b=a[::2]
    else:
        b=a[1::2]
    c=[eval(i) for i in b]
    return sum(c)
    
def main(number):
    if (sumOfDoubleEvenPlace(number)+sumOfOddPlace(number))%10==0 and isValid(number) is True:
        return True
    else:
        return 'invalid number'

print(main(number))
