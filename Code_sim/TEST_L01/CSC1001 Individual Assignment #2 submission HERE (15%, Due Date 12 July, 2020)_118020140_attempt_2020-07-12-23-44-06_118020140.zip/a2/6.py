import random
 
def conflict(state, nextX):#the next Queen is at (x,y)
    nextY = len(state)#e.g. state=[5,3,6,0] means there are Queens at (5,0)(3,1)(6,2)(0,3)
    for i in range(nextY):
        if state[i]==nextX or abs(state[i] -nextX) == nextY - i:#check whether the new Queen conflicts with the state.
            return True
    return False
 
def queens(num=8, state=()):#creat a recursion
    for pos in range(num):
        if not conflict(state, pos):
            if len(state) == num-1:
                yield(pos,)
            else:
                for result in queens(num, state + (pos,)):
                    yield (pos,) + result
        else: pass

def prettyprint(solution):
    for pos in solution:
        print('·  ' * (pos) + 'Q  ' + '·  ' * (7-pos))

prettyprint(random.choice(list(queens(8))))
