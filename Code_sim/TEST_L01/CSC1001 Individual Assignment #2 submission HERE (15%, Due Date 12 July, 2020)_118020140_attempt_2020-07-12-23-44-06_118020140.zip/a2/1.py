def sqrt(n):
    lastGuess=1
    nextGuess = (lastGuess + (n / lastGuess)) / 2
    while lastGuess>0:
        lastGuess=nextGuess
        nextGuess = (lastGuess + (n / lastGuess)) / 2
        if lastGuess-nextGuess<0.0001 and lastGuess-nextGuess>-0.0001 :
             break
    return nextGuess
a=eval(input('Please input a nember:'))
print( 'The approximated square root of n is: ',sqrt(a))


