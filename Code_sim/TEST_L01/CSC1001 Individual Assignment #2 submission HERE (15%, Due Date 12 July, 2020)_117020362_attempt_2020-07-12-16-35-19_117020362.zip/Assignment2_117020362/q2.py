def is_primes(num):
    n = 0
    for i in range(2, int(num / 2) + 1):
        if num % i == 0:
            n += 1
    if n == 0:
        return True
    else:
        return False
def not_palindrome(number):
    number_list = []
    number_repeat = number
    while True:
        number_list.append(number_repeat % 10)
        if number_repeat / 10 < 1:
            break
        else:
            number_repeat = number_repeat // 10
    reverse = 0
    n = 1
    for i in number_list[::-1]:
        reverse += i * n
        n = n * 10
    if reverse == number:
        return False
    else:
        return True
def main():
    NUMBER_LIMITED = 100
    n = 0
    i = 1
    while n < NUMBER_LIMITED:
        if is_primes(i) and not_palindrome(i):
            print(format(i, "3"), end="   ")
            n += 1
            i += 1
            if n % 10 == 0:
                print()
        else:
            i += 1
            continue

main()
