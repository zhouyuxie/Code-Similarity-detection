num=eval(input("please enter a credit card number: "))
if 13<=len(str(num))<=16:
    def sumOfDoubleEvenPlace(num):
        totalsum =0
        crd_no=str(num)[::-1]
        def getDigit(num):
            for i in range(len(crd_no)):
                if i%2==1 and int(i)*2 <10:
                    totalsum=totalsum+int(i)*2
                    getDigit(num)==int(i)
                elif i%2==1 and int(i)*2>=10:
                    for j in str(int(i)*2):
                        totalsum=totalsum+int(j)
                        getDigit(num)==int(j)
                return getDigit(num)
        return totalsum

    def sumOfOddPlace(num):
        return sum([int(i) for i in str(num)[1::2]])

    def finalresult(num):
        return sumOfDoubleEvenPlace(num)+sumOfOddPlace(num)

    def isValid(num):
        if finalresult(num) %10 == 0:
            print("The number of the credit card is valid")
        else:
            print("The number of the credit card is invalid")
    print(isValid(num))
else :
    print("The length of the credit card is invalid")

