startvalue=None
lastGuess=None
nextGuess=None
startvalue=eval(input("initial guess: "))
def sqrt(n):
            lastGuess=startvalue
            nextGuess=(lastGuess+(n/lastGuess))/2
            while abs(nextGuess**2-n) > 0.0001:
                    lastGuess=nextGuess
                    nextGuess=(lastGuess+(n/lastGuess))/2
            return nextGuess
print(sqrt(n))
