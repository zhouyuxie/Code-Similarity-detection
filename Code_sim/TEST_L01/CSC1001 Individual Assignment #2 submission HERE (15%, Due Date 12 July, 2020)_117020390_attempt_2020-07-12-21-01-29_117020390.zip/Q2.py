print("the first 100 emirps are:\n")
count=0
for i in range(2,1000000): #iteration to find out primes.
    for j in range(2,i):
        if i%j==0: break
    else:
        string=str(i)
        string_reverse=string[::-1] #transfer int to str so that it can be reversed.
        x=int(string_reverse) #transfer reversed str to int again.
        for y in range(2,x): #find out primes from reversed primes.
            if x%y==0: break
        else:
            if i>11 and i!=x: #get rid of units digit and palindromics.
                print(str(i).rjust(4," "),end="  ") #transfer int to str so that it can be aligned to the right.
                count=count+1
                if count%10==0:
                    print("\n") #start a new line for every ten numbers.
                if count==100: break
print("finished")
            
