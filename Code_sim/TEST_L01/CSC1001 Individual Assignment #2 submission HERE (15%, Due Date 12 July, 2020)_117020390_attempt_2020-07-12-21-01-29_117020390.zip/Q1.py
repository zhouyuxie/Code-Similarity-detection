n=float(input("give me a number: "))
def sqrt(n):
    import random
    initial=random.random() #use random() to create an initial value.
    guess=(initial+(n/initial))/2
    if abs(guess-initial)>0.00001:
        new_guess=(guess+(n/guess))/2
        while abs(guess-new_guess)>0.00001:
            guess=new_guess #while last doesn't approciamte sqrt, conduct the loop.
            new_guess=(guess+(n/guess))/2
        else:
            print("the approximate squareroot of",n,"is",new_guess)
    else:
        print("the approximate squareroot of",n,"is",guess)

sqrt(n)
            
