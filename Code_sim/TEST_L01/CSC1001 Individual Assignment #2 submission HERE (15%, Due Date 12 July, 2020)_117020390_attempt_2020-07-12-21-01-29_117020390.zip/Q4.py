s1=input("input the first word: ")
s2=input("input the second word: ")
def isAnagram(s1,s2):
    lst1=[]
    lst2=[]
    for i in range(len(s1)):
        lst1.append(s1[i])
        list1=sorted(lst1)
    for j in range(len(s2)):
        lst2.append(s2[j])
        list2=sorted(lst2)
    if list1==list2:
        print(s1,"and",s2,"are anagrams.")
    else:
        print(s1,"and",s2,"are not anagrams.")

isAnagram(s1,s2)
