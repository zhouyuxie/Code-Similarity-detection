lockers=[False]*100 # False represents closed.
for i in range(1,101): #for the i.th round of changing lockers.
    for j in range(1,101): #for the j.th lockers to be changed in that round.
        num=i*j #num represents the serial number of the lockers changed.
        if (num<=100) and (lockers[num-1]==False): #num must be smaller than 100 for there are only 100 lockers.
            lockers[num-1]=True #change the status of the locker.
        elif (num<=100) and (lockers[num-1]==True):
             lockers[num-1]=False
        else: break
numOfOpenLockers=sum(lockers)
print("After 100 round of changes, there are",numOfOpenLockers,"lockers open.")
openLockers=[]
for a in range(len(lockers)):
    if lockers[a]==True:
        openLockers.append(a+1)
print("the serial numbers of open lockers are:",openLockers) #the serial number of open lockers.
        
