print("one solution for 'eight-queens' problem is:")
def conflict(state, next_row): #conflict function to check whether a queen is in a qualified position.
    next_column = len(state) #row represents which row the queen is and cloumn is as the same.
    for i in range(next_column):
        if abs(state[i]-next_row) in (0, next_column-i): #if 0, the two queens are in the same cloumn; if next_column-i, the two queens are in the same diagnal.
            return True #if there is conflict return true.
    return False #if there is no conflict return false.

def queen(num=8, state=()): #num is the number of queens and is 8 in this problem.
    for pos in range(num):
        if not conflict(state, pos): #if there is no conflict in positions.
            if len(state)==num-1: #when len(state)==7, there is only last one queen to display.
                yield (pos,)
            else:
                for result in queen(num, state+(pos,)): #recursion to determine queens' positions. 
                    yield (pos,)+result

def board(solution): #to illustrate a chessboard.
    print(" _"*8)
    def row(pos, length=len(solution)): #to illustrate each row of the board.
        return "|_"*(pos)+"|Q|"+"_|"*(length-pos-1) #display queens.
    for pos in solution:
        print(row(pos))

import random 
board(random.choice(list(queen(8)))) #use random.choice to only display one solution.
