number=int(input("input the credit card number: "))
digit_list=[]
sumOfDoubleEven=0
sumOfOdd=0
def getDigit(number): #function to get single digits.
    string=str(number)
    for i in range(len(string)):
        if i%2==0:
            x=2*int(string[i]) #for even place numbers, times 2 to get digits.
            if x<10: 
                single_digit=x
            else: #if the digits are larger than 10 (taht is have two units)
                unit=int(x%10) #calculate 个位
                ten=int((x%100-unit)/10) #calculate 十位
                single_digit=unit+ten
            digit_list.append(single_digit)
def sumOfDoubleEvenPlace(number): #function to calculate sum of digits.
    getDigit(number)
    global sumOfDoubleEven
    for j in digit_list:
        sumOfDoubleEven=sumOfDoubleEven+j
def sumOfOddPlace(number): #function to calculate sum of odd place numbers.
    string=str(number)
    global sumOfOdd
    odd_list=[]
    for i in range(len(string)):
        if i%2!=0:
            odd_list.append(int(string[i]))
    for j in odd_list:
        sumOfOdd=sumOfOdd+j
def isValid(number): #final function to test card number is valid or not.
    sumOfDoubleEvenPlace(number)
    sumOfOddPlace(number)
    result=sumOfDoubleEven+sumOfOdd
    if result%10==0:
        print("the credit card numebr is valid")
    else:
        print("the credit card number is invalid")

isValid(number)
    
        
        
                    
