def isAnagram(s1,s2):
    s1List = list(str(s1))
    s1List.sort()
    s2List = list(str(s2))
    s2List.sort()
    if s1List == s2List:
        return True
    else:
        return False
def main():
    s1,s2 = input("Enter two strings separated by a comma:").split(",")

    if isAnagram(s1,s2):
        print("It is an anagram.")
    else:
        print("It is not an anagram.")
main()