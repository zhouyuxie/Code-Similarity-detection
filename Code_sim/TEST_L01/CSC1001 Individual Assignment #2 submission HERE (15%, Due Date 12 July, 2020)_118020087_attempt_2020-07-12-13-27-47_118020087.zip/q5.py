def lockerPuzzle(n):
    lockers = [False] * n
    for s in range(n):
        for l in range(s,n,s + 1):
            lockers[l] = not lockers[l]
    return lockers
for i, locker in enumerate(lockerPuzzle(100),1):
    if locker == True:
        print(i)
       
