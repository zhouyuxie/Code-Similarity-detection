def isPrime(number):
    divisor=2
    while divisor<=number/2:
        if number%divisor==0:
            return False
        else:
            divisor+=1
            continue
    return True

def reverse(number):
    reverseNumber=''
    while number != 0:
        reverseNumber+=str(number%10)
        number//=10
    reverseNumber=int(reverseNumber)
    return reverseNumber

def main():
    count=0
    number=1
    while count < 100:
        if isPrime(number) and isPrime(reverse(number)) and number != reverse(number):
            print("%6d"%number,end='')
            count+=1
            number+=1
        else:
            number+=1
            continue            
        if count%10==0:          #Change line after every 10 numbers
            print()

main()
