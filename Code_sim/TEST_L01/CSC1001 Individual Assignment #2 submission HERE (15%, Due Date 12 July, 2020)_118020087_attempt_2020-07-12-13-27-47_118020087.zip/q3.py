def getDigit(number):
    sum = 0
    for i in str(number)[len(str(number))-2::-2]:
        if int(i) * 2 < 10:
            sum = sum + int(i) * 2
        else:
            for j in str(int(i) * 2):
                sum = sum + int(j)
    return sum

def sumOfDoubleEvenPlace(number):
    return getDigit(number)

def sumOf0ddPlace(number):
    sum = 0
    for i in str(number)[len(str(number))-1::-2]:
        sum = sum + int(i)
    return sum

def isValid(number):
    result = sumOf0ddPlace(number) + sumOfDoubleEvenPlace(number)
    if result % 10 == 0:
        return True
    else:
        return False

def startValid(number):
    if str(number)[0] == '4' or str(number)[0] == '5' or str(number)[:1] == '37':
        return True
    else:
        return False
def num(number):
    if len(str(number)) >= 13 and len(str(number)) <=16:
        return True
    else:
        return False
def main():
    number = eval(input("Please enter your card number:"))
    if isValid(number) and startValid(number) and num(number):
        print("Valid!")
    else:
        print("Invalid!")
main()