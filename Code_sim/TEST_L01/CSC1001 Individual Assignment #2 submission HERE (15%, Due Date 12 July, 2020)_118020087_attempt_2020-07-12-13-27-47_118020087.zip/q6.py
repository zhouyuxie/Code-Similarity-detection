import random

def isWrong(state, nextqX):
    nextqY = len(state)

    for i in range(nextqY):
       # next to or on the diagonal
        if abs(state[i] - nextqY) == abs(i - nextqX):
            return True
    return False

def queens(num, state=()):

    for pos in range(num):
        if not isWrong(state, pos):
            if len(state) == num - 1: # This is the last queen
                yield (pos,)  # generate a tuple
            else:
                for result in queens(num, state + (pos,)):
                    yield (pos,) + result

def illustrated(solution):
    def line(pos, length=len(solution)):
        if pos != 0:
            return '| ' * (pos - 1) + '|Q' + '| ' * (length - pos + 1)
        else:
            return '| ' * (pos - 1) + '|Q' + '| ' * (length - pos)

    for ele in solution:
        print(line(ele))

def main():
    illustrated(random.choice(list(queens(8))))

main()