def sqrt(n):
    lastGuess = 1
    nextGuess = 0
    while True:
        nextGuess = (lastGuess + (n/lastGuess))/2
        if abs(nextGuess - lastGuess) >= 0.0000001:
            lastGuess = nextGuess
            continue
        else:
            break
    return nextGuess

def main():
    while True:
        n = eval(input("Enter a number:"))
        if n >= 0:
            print("Its square root is",sqrt(n))
            break
        else:
            print("Invalid!")
            continue

main()