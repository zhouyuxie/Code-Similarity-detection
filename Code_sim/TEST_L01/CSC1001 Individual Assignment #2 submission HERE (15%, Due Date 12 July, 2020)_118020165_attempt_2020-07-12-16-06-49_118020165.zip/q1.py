def sqrt(n):
	lastGuess=1
	nextGuess=(lastGuess + (n / lastGuess)) / 2
	while (nextGuess-lastGuess)>0.0001 or (nextGuess-lastGuess)<-0.0001:
		lastGuess=nextGuess
		nextGuess=(lastGuess + (n / lastGuess)) / 2
	print(nextGuess)

n=input('please input a positive number:')
try:
        a=float(n)
        sqrt(a)
except:
        print('please input a positive number')
