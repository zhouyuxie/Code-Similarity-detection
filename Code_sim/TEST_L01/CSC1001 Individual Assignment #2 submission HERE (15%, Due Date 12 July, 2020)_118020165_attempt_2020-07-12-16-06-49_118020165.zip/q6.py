import random
def print_Line(x):
	for i in range(8):
		if (x[i]==1):
			print("{:^2}".format("|Q"),end='')
		else:
			print("{:^2}".format("| "),end='')
	print('|')
def print_test(x):
	for i in range(8):
		if (x[i]==1):
			print("%2s" % ("|Q"),end='')
		elif (x[i]==0):
			print("%2s" % ("|X"),end='')
		else:
			print("%2s" % ("| "),end='')
	print('|')
def test():
	gen = [[-1,-1,-1,-1,-1,-1,-1,-1],[-1,-1,-1,-1,-1,-1,-1,-1],[-1,-1,-1,-1,-1,-1,-1,-1],[-1,-1,-1,-1,-1,-1,-1,-1],[-1,-1,-1,-1,-1,-1,-1,-1],[-1,-1,-1,-1,-1,-1,-1,-1],[-1,-1,-1,-1,-1,-1,-1,-1],[-1,-1,-1,-1,-1,-1,-1,-1]]
	for i in range(8):
		limit=8
		for j in range(8):
			if gen[i][j]==0:
				limit-=1
		rand=random.randrange(limit)
		pr_rand = rand
		pos = -1
		while (rand>=0):
			pos+=1
			if(gen[i][pos]<0):
				rand-=1
		gen[i][pos]=1
		before = pos
		after = pos
		for j in range(i+1,8):
			before-=1
			after+=1
			gen[j][pos]=0
			if before>=0:
				gen[j][before]=0
			if after<=7:
				gen[j][after]=0
	for i in range(8):
		print_Line(gen[i])

result = False
while result is False:
	try:
		test()
		result = True
	except:
		pass
