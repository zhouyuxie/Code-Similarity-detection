lockers=[False]*100
for s in range(100):
    for l in range (s,100,s+1):
        lockers[l]=not lockers[l]
print('the state of lockers:','\n',lockers)
print('the number of opened lockers:')
for i in range(100):
    if lockers[i]:
        print(i+1)
