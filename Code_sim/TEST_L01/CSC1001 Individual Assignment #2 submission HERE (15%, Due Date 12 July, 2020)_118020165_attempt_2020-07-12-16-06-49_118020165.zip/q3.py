# Return True if the card number is valid
def isValid(number):
	if (number/(10**12)<1) and (number/(10**15)>=10):
		return False
	else:
		count = 0
		test = number
		while (test>=1):
			count+=1
			test=test/10
		trigger = False
		for i in [4,5,6]:
			if int(number/(10**(count-1)))==i:
				trigger = True
				break
		if (int(number/10**(count-2))==37):
			trigger = True
		if(trigger==False):
			return False
		Valid=sumOfDoubleEvenPlace(number)+sumOfOddPlace(number)
		if Valid%10==0:
			return True
		else:
			return False

# Get the result from Step 2
def sumOfDoubleEvenPlace(number):
	Digit=0
	number=int(number/10)
	while (number!=0):
		Digit+=getDigit((number%10)*2)
		number=int(number/100)
	return Digit

# Return this number if it is a single digit, otherwise, return
# the sum of the two digits
def getDigit(number):
	return int(number/10)+(number%10)
	
# Return sum of odd place digits in number
def sumOfOddPlace(number):
	Digit=0
	while (number!=0):
		Digit+=number%10
		number=int(number/100)
	return Digit
number=eval(input('enter a credit card number:'))
if isValid(number):
        print('is valid')
else:
        print('is invalid')

