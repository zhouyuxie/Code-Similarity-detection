str1=str(input('enter the first string:'))
str2=str(input('enter the second string:'))
def isAnagram(str1, str2):
    list1=list(str1)
    list1.sort()
    list2=list(str2)
    list2.sort()
    if list1==list2:
        return print('is an anagram')
    else:
        return print('is not an anagram')
    
isAnagram(str1, str2)
