def determine(num):#determine whether it is prime number
	i=2
	judge = 1
	while (i<num):
		if (num%i)==0 :
			judge = 0
			return judge
		else:
			i=i+1
			continue
	return judge
def reverse(x):
	rev=0
	while (x>0):
		rev = (rev * 10) + x % 10
		x = int(x/10)
	return rev
def emirp(x):#determine whether it is emirp
	if (determine(x)==1 and determine(reverse(x))==1 and x!=reverse(x)):
		return 1
	else:
		return 0
count = 0
i=1
while count<100:
	if (emirp(i)==1):
		print (str(i).rjust(5),'\t',end = '')
		count+=1
		if count%10==0:
			print('\n',end='')
	i+=1