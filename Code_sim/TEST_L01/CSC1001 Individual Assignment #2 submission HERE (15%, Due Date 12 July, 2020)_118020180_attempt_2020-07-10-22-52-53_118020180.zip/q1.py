def sqrt(n):
    if n < 0:
        return print("Invalid input")  #make sure no negative input will go to the following loop
    elif n == 0:
        return 0 #directly give out the square root of 0
    else:
        nextGuess = 1     #randomly set the first and the second guess
        lastGuess = 0.5   #the answer won't be affected to much
        while abs(lastGuess - nextGuess) > 0.0001:
            lastGuess = nextGuess
            nextGuess = (lastGuess + (n / lastGuess)) / 2
        return nextGuess  #return the value of the next guess when the program is done
