##define a function to simulate the operation of a student
def operation(locker):
    if locker == True:
        return False
    else:
        return True

##set all the lockers to be locked
lockers = list()
for i in range(0,100):
    lockers.append(False)

stnum = 1
while stnum < 100:
    for stnum in range(stnum,101):  
        for j in range(1,101):      
            if j % stnum == 0:            ##the ith student will do his operation
                lockers[j-1] = operation(lockers[j-1])  ##locker situation changed
    stnum += 1

##to display the opened lockers
count = 1
for locker in lockers:
    if locker == True:
        print(count)
        count += 1
    else:
        count += 1
