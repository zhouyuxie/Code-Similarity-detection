##define the function to see whether the strings inputted are anagrams
def isAnagram(s1,s2):
    list1 = list()
    list2 = list()
    for i in s1:
        list1.append(i)
    for j in s2:
        list2.append(j)
    if list1.sort() == list2.sort():
        return True
    else:
        return False

##ask the user to enter the strings and call the function
s1 = input("Please enter the first string:")
s2 = input("Please enter the second string:")
if isAnagram(s1,s2):
    print("is an anagram")
else:
    print("is not an anagram")
