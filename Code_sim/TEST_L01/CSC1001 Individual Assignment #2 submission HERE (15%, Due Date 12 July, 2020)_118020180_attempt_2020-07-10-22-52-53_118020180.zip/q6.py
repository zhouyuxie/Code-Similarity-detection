import random
##Define the function to check whether the queen is able to be put their or not.
def confict(positions, Y):
    nextY = len(positions)
    if Y in positions: return True   ##If the vertical coordinate of this queen is the same as one of the previous queens
    for i in range(nextY):
        if nextY - Y == i - positions[i]:
            return True
        if nextY + Y == i + positions[i]:##or this queen is placed on the diagonal line of one of the previous queens, there is a confliction.
            return True
    return False

##Define the function to find the locations of the queens.
def locateQueens(num, positions = ()):
    if num - 1 == len(positions):      ##If the lenth of "state" reaches to 7, there is only one queen left.
        for i in range(num):
            if not confict(positions, i):   ##If there is no confliction between this queen and previous queens,
                yield (i,)              ##the queen's position is generated. As a result, the positions of the previous queens are sured
    else:                               ##and yield and added to the answer.
        for Y in range(num):
            if not confict(positions, Y):           ##If the queen's position has no confliction with previous queens, the program go further.
                for result in locateQueens(num, positions + (Y,)):  ##The program go further(iterate).
                    yield (Y,) + result ##Add a queen's vertical coordinate to the tuple.
                                          ##The horizontal coordinate of this queen is the index of the vertical coordinate in the tuple.

##Display the queens on the board.
a = random.choice(list(locateQueens(8)))##Randomly choose one of the 92 answers.
print(a)
for i in a:
    x = a.index(i)
    y = int(i)
    print("|" + " |" * y + "Q" + "| " * (7-y) + "|") ##Display the answer.

