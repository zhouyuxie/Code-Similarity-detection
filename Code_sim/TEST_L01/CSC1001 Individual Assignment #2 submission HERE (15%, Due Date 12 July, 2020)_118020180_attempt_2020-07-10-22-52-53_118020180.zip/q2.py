##define a function to obtain the reverse of the number 
def reverse(number):
    reverseNumber = ''
    while number != 0:
        reverseNumber += str(number%10)
        number //= 10
    reverseNumber = int(reverseNumber)
    return reverseNumber

##define a function to see whether the number is a palidrome
##if it is a palidrome, return False
##if it isn't, return True
def isNotPalindrome(number):
    if number == reverse(number):
        return False
    else:
        return True

##define a function to see whether the number is a prime number
def isPrime(number):
    divisor = 2
    while divisor <= number / 2:
        if number % divisor == 0:
            return False
        else:
            divisor += 1
            continue
    return True

##define a main function to display 100 nnumbers which are emirps
def main():
    count = 0
    number = 10
    while count < 100:
        if isPrime(number) and isNotPalindrome(number)and isPrime(reverse(number)):
        ##the number should be a prime number
        ##the number's reverse should be a prime number
        ##the number shouldn't be a palindrome
            print('%6d'%number,end='')
            count += 1
            number += 1
        else:
            number +=1
            continue
        if count % 10 == 0:
            print()
main()
    
