##Return true if the card number is started with a valid start
def startswithValid(number):
    number = str(number)
    if number.startswith('4'):
        return True
    elif number.startswith('5'):
        return True
    elif number.startswith('37'):
        return True
    elif number.startswith('6'):
        return True
    else:
        return False

##Return this number if it is a single digit, otherwise, return
##the sum of the two digits
def getDigit(number):
    if number >= 10:
        number = number % 10 + number // 10
    else:
        number = number
    return number

##Get the result from step 2
def sumOfDoubleEvenPlace(number):
    count = 1
    sumnum = 0
    while number > 0:
        digit = number % 10
        number //= 10
        if count % 2 == 0:
            sumnum += getDigit(2 * digit)
            count += 1
        else:
            count += 1
    return sumnum

##Return sum of odd place digits in number
def sumOfOddPlace(number):
    count = 1
    sumnum = 0
    while number > 0:
        digit = number % 10
        number //= 10
        if count % 2 == 1:
            sumnum += digit
            count += 1
        else:
            count += 1
    return sumnum

##define a function to see whether the card number is valid
def isValid(number):
    if startswithValid(number) and (sumOfDoubleEvenPlace(number) + sumOfOddPlace(number)) % 10 ==0:
        print('The card number is valid!')
    else:
        print('The card number is invalid!')

##require the user to input the card number 
number = eval(input("Please enter your card number:"))
##call the isValid function to see whether the number is valid
isValid(number)
    
