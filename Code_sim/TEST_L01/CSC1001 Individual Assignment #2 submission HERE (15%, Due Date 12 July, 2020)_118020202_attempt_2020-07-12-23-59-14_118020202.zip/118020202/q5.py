##Create a list to represent lockers
locker=[]
for l in range(0,100):
  locker+=[False]

##Use for loop to simulate the process
for s in range(0,100): 
  for i in range(s,100,s+1):
    if locker[i]== False:
        locker[i]=True
    elif locker[i] == True:
        locker[i]=False

##Use for loop to get the result 
answer=[]
for k in range(0,100):
  if locker[k]==True:
    ##the lockers'number is equal to the list number plus one   
    answer+=[k+1]
##Display the result
print ('The lockers',answer,'are open')


