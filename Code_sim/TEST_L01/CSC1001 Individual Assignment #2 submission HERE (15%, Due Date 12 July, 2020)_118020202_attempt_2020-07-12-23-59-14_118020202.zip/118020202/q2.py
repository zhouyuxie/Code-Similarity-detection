##Define a function to obtain the reverse of a number
def reverse(n):
  reverseNo=''
  while n !=0:
    reverseNo+=str(n%10)
    n//=10
  reverseNo=int(reverseNo)
  return reverseNo

##Define a function to judge whether a number is a prime
def isPrime(n):
  i=2
  while i<=(n/2):
    if n%i==0:
      return False
    else:
      i+=1
      continue
  return True

##Define a function to judge whether a number is an emirp
def isEmirp(n):
  if isPrime(reverse(n)) and isPrime(n):
    return True
  else:
    return False

##Define a function to judge whether a number is not a palindrome
def isnotPalindrome(n):
  if n!=reverse(n):
    return True
  else:
    return False

##Define a main function to display 100 numbers which are emirp  
def main():
  ##Begin from the smallest emirp 13
  count=0
  n=13
  while count<100:
    if isPrime(n) and isEmirp(n) and isnotPalindrome(n):
      print('%6d'%n,end='')
      count+=1
      n+=1
    else:
      ##Turn to the next number if it is not emirp    
      n+=1
      continue
    ##Change line after every 10 numbers    
    if count%10==0:
      print()

main()
