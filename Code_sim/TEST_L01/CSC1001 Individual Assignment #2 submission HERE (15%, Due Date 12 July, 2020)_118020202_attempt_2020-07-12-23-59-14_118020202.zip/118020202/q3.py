##Define a function to get the result from Step2
def sumOfDoubleEvenPlace(n):
  n1=[]
  count=1
  for j in n:
    if count%2 == 0:
      n1+=n[count-1]
      count+=1
    else:
      count+=1
  sumDE=0
  for i in n1:
    i=int(i)
    i=getDigit(i)
    sumDE=sumDE+i
  return sumDE
  
##Return this number if it is a single digit,
##otherwise, return the sum of the two digits
def getDigit(n):
  if (n*2)//10==0:
      n=n*2
  else:
      n=(n*2)//10+(n*2)%10
  return n

##Return sum of odd place digits in number
def sumOfOddPlace(n):
  n2=[]
  count=1
  for j in n:
    if count%2!=0:
      n2+=n[count-1]
      count+=1
    else:
      count+=1
  sumO=0
  for i in n2:
    i=int(i)
    sumO+=i
  return sumO
  
##Return true if the card number is valid
def isValid(n):
  if len(n)<13 or len(n)>16 :
    return False
  else:
    if isStartValid(n):
      va=sumOfOddPlace(n)+sumOfDoubleEvenPlace(n)
      if va%10 == 0:
        return True
      else:
        return False
    else:
      return False



##Using string to define reverse function
def reverse(number):
    reverseNumber=''
    while number != 0:
        reverseNumber+=str(number%10)
        number//=10
    return reverseNumber

##Return true if the beginning number of the card is valid
def isStartValid(n):
  if (n[len(n)-1] == '3' and n[len(n)-2] == '7'):
      return True
  elif n[len(n)-1] == '4':
      return True
  elif n[len(n)-1] == '5':
      return True
  elif n[len(n)-1] == '6':
      return True
  else:
      return False
  


##Use try except to capture the error
##Promote the indicator for users to enter    
try:
  number=int(input("Enter a credit card number:"))
except:
  number=None

##Use above function to judge whether the number is valid
if number is None:
  print("Your input is wrong")
else:
  number=reverse(number)
  n=list(map(str,number))
  if isValid(n):
     print('Your credit card number is valid')
  else:
     print('Your credit card number is invalid')



