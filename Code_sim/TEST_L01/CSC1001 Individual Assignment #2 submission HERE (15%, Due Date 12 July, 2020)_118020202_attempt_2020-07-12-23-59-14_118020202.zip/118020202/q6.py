import random
import sys
sys.setrecursionlimit(20000)
queens=[]
for i in range(0,8):
    queens+=[i]

def check(queens):
    for i in range(0,8):
      for j in range(i+1,8):
          if abs(queens[i]-queens[j])==int(j-i):
              random.shuffle(queens)
              check(queens)
    return queens

queens=check(queens)
queens=check(queens)
print(queens)

for row in range(0,8):
  board='|'
  for i in range(0,8):
    if queens[row]==i:
        board+='Q|'
    else:
        board+=' |'
  print(board)
print('')
