##Use try except to capture the error 
##Prompt up the indicators for users to enter
try:
  n=eval(input("Enter the number:")) 
  lastGuess=eval(input("Enter the initial guess:"))
except:
  n=None
  lastGuess=None

##Define a function to calculate the square root
def sqrt(n,lastGuess):
  nextGuess=(lastGuess+(n/lastGuess))/2
  dif=nextGuess-lastGuess
  ##Use if to get the absolute value of dif
  if dif<0:
    dif=-dif
  while dif>=0.0001:
    lastGuess=nextGuess
    nextGuess=(lastGuess+(n/lastGuess))/2
    dif=nextGuess-lastGuess
    if dif<0:
      dif=-dif
  return(nextGuess)

if n is None or lastGuess is None:
  print('Your input is wrong' )
##Display the result
else:
  print('The square root of',n ,'is',sqrt(n,lastGuess))

