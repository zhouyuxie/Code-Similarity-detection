##Prompt the indicators for users to enter
s1=str(input("Enter the first word:"))
s2=str(input("Enter the second word:"))

##Define a function to check whether the two words are anagram
def isAnagram(s1, s2):  
    m1=list(map(str,s1))
    m2=list(map(str,s2))
    m1.sort()
    m2.sort()
    if len(m1) != len(m2):
        return False
    else:
      for i in range(0,len(m1)):
        if m1[i] != m2[i]:
            return False
        else:
            continue
      return True

##Display the conclusion
if isAnagram(s1,s2):
    print (s1,'and',s2,'are anagrams')
else:
    print (s1,'and',s2,'are not anagrams') 



