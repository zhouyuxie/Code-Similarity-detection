def EightQueen(board,row):

    boardLen = len(board)

    if row == boardLen:    ##when comes to the next line of the last line 
        printBoard(board)
        return True

    col = 0
    while col < boardLen:
        if check(board,row,col):

            board[row] = col
            if EightQueen(board,row+1): ##iterate the next line
                return True
                
        col += 1
    return False

##Check wether current location (row, col) can place a queen
def check(board, row, col):
    i = 0
    while i < row:
        if abs(col-board[i]) in (0,abs(row-i)):
            return False
        i += 1
    return True

def printBoard(board):

    for index,col in enumerate(board):
        print('| ' * col + '|Q' + '| ' * (len(board) - col) )

def main():

    BOARD_lENGTH = 8 # set the board length
    board = list(None for x in range(BOARD_lENGTH))
    EightQueen(board, 0)

main()
