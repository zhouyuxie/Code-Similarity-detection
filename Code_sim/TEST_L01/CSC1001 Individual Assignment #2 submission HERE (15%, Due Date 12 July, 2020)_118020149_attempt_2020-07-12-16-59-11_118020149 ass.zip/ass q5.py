l=list()
for i in list(range(0,100)):
    l.append(False)

#When the first student comes
for i in list(range(0,100)):
    l[i]=True
#When the second student comes
for i in list(range(1,100)):
    l[i]=False
#When the third,forth,..,one hundredth student comes
for student in list(range(2,100)):
    for i in list(range(student,100)):
        if (i+1)%(student+1)==0:
            l[i]=not l[i]

print(l)
