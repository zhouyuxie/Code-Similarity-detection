def sqrt(n):
    ##Prompt the user to enter a guess
    lastGuess=eval(input('Enter a positive value:'))
    
    while lastGuess>0:
        nextGuess=(lastGuess+(n/lastGuess))/2 ##Use the given function
        
        if -0.0001<nextGuess-lastGuess<0.0001:
            print('The approximated squre root of n is %2f'%nextGuess)
            break ##End the loop
        else:
            lastGuess=nextGuess
            continue ##Repeat the while loop

##For example, approximate the square root of 2 (n=2)
sqrt(2)
