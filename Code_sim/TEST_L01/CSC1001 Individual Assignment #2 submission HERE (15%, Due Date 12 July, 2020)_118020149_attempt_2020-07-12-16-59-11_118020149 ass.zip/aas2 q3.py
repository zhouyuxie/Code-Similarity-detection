def reverse(number):
    reversenumber=''
    l=len(str(number))
    for i in list(range(l-1,-1,-1)):
        reversenumber += str(number)[i]
    reversenumber=int(reversenumber)
    return reversenumber          
            
def sumOfDoubleEvenPlace(number):
    number=reverse(number)
    l=len(str(number))
    sumDigit=0
    for i in list(range(0,l)):
        if i%2 != 0:
            m=2*eval(str(number)[i])
            if m>=10:
                m=m%10+1
            sumDigit+=m
    
    return sumDigit

def sumOfOddPlace(number):
    number=reverse(number)
    l=len(str(number))
    sumRestDigits=0
    for i in list(range(0,l)):
        if i%2 == 0:
            n=eval(str(number)[i])
            sumRestDigits+=n
    
    return sumRestDigits

def getDigit(number):
    digit=sumOfDoubleEvenPlace(number)+sumOfOddPlace(number)
    
    return digit

def isValid(number):
    if getDigit(number)%10==0:
        print('Your credit card number is valid.')
        return True
    else:
        print('Your credit card number is invalid.')
        return False

isValid(eval(input('Enter your credit card number here:')))
            
