##Define a function to obtain the reverse of a number
def reverse(number):
    reversenumber=''
    l=len(str(number))
    for i in list(range(l-1,-1,-1)):
        reversenumber += str(number)[i]
    reversenumber=int(reversenumber)
    return reversenumber

##Define a function to judge whether a number is nonpalindrome
def notPalindrome(number):
    if number != reverse(number):
        return True
    else:
        return False

##Define a function to judge whether a number is a prime
def isPrime(number):
    divisor=2
    while divisor<=number/2:
        if number%divisor==0:
            return False
        else:
            divisor+=1
            continue
    return True

##Define a main function to display the first 100 emirps.
def main():
    count=0
    number=2
    while count<100:
        if notPalindrome(number) and isPrime(number) and isPrime(reverse(number)):
            count+=1
            if count%10 != 0:
                print("%6d"%number,end='')
            else:
                print('%6d'%number)
            number+=1
        else:
            number+=1
            continue

main()
