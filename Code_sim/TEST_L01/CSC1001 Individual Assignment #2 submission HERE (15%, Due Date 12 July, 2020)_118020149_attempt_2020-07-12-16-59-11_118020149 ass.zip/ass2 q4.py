def isAnagram(s1,s2):
    l1=list()
    for i in list(range(0,len(s1))):
        l1.append(s1[i])
    l2=list()
    for j in list(range(0,len(s2))):
        l2.append(s2[j])
    l1.sort()
    l2.sort()
    if l1==l2:
        print('is an anagram.')
        return True
    else:
        print('is not an anagram.')
        return False

s1=input('Enter a word here:')
s2=input('Enter another word here:')
isAnagram(s1,s2)
