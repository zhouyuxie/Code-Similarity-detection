def LockerPuzzle(n):

    # create a LockerList to store the status of lockers
    LockerList = []
    # initially, all the lockers are locked
    for i in range(n):
        LockerList.append(False)
    
    # each student will change the status of lockers under certain pattern
    for stud in range(n):
        for l in range(stud, n, stud + 1):
            LockerList[l] = not LockerList[l]
    # after all the students leave, LockerList stores the infomation of lockers
    return LockerList


# print out the lockers that are open in the end
# actully the open lockers will be those that are perfect squares, since they have odd number of divisiors. 
# which means their final status will be the opposite from the very beginning 
print('The lockers that are left open are:')
for i, locker in enumerate(LockerPuzzle(100), 1):
    if locker:
        print(i,end=' ')