import random

# create a dictionary o store the position of each queen 
queens_dict = {}
for i in range(1,9):
    queens_dict[i] = 0

# print the chessbord with queens on its position
def getRows(x):
    for i in range(1,9):
        if i != x:
            print('| ', end = '')
        else:
            print('|Q', end = '')
    print('|')

# for a specified queen, check whether there's another queen on the same row, column or diagonal
def checkOne(a, x):
    queens_dict[a] = x
    for i in range(1,a):
        if x == queens_dict[i] or abs(queens_dict[i] - x) == abs(a - i):
            return False
    return True

# check if all the queens meet the conditions
# if not, reset the queen(s) and check again
def checkAll(): 
    count = 0
    for col in range(1,9):
        x = random.randint(1,8)
        for i in range(1,9):
            if checkOne(col, x) == True:
                count += 1
                break
            else:
                x = random.randint(1,8)            
    if count == 8:
        return True
    else:
        return False

# while all conditions are met, out put the final solution
def main():
    while True:
        if checkAll():
            for i in range(1,9):
                getRows(queens_dict[i])
            break

# call the function
main()





