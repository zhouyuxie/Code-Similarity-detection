import random
import math

def sqrt(n):
    if n < 0:
        return 'Only non-negative numbers have square root.'
    elif n == 0:
        return 0
    else:
        # set a random positive number as the initial guess
        lastGuess = random.randint(1,100)
        nextGuess = ((lastGuess + n/lastGuess))/2
        while True:    
            if abs(lastGuess-nextGuess) <= 0.0001:                  
                return nextGuess
            else:                                                     # perform the Babylonian method
                lastGuess = nextGuess
                nextGuess = nextGuess = (lastGuess + (n / lastGuess)) / 2

n = eval(input('Enter a non-negativfe number and get its square root: '))
print(sqrt(n))