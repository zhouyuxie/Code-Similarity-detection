words = input("enter two words and check whether they are anagrams or not, please separate them using ',': ")
words = words.split(',')      # split the input into two words

# remove white spaces before and after the words
# change all the letters into lower case
s1 = words[0].strip()
s2 = words[1].strip()
s1 = s1.lower()
s2 = s2.lower()


def isAnagram(s1,s2):
    # change the data type of the input words: string -> list
    list1 = []
    list2 = []
    for i in range(len(s1)):
        list1.append(s1[i])
    for i in range(len(s2)):
        list2.append(s2[i])
    # sort the word lists and compare
    if list1.sort() == list2.sort():
        return True
    else: 
        return False

def main():
    if isAnagram(s1,s2):
        print("'",s1,"'",'and',"'",s2,"'",'is an anagram')
    else:
        print("'",s1,"'",'and',"'",s2,"'",'is not an anagram')

# call the function
main()


