n = input('Please enter a credit card number: ')
number = str(n)[::-1] # reverse the card number for convenience

# check the starting number and the length of the card number 
def checkConditions(n):
    if len(n) in [13,14,15,16]:
        if n.startswith("4") == True:
            return True
        elif n.startswith("5") == True:
            return True
        elif n.startswith("37") == True:
            return True
        elif n.startswith("6") == True:
            return True
        else:
            return False
    else:
        return False

# prepare the operarions that need to be performed on digits in the even places
def getDigits(doubledigit):
    if 0 <= doubledigit < 10:
        return int(doubledigit)
    else:
        return int(doubledigit%10 + doubledigit//10)

# get the sum of doubled even-place digits using predifined getDigits function
def sumOfDoubleEvenPlace(numebr):
    sumEven = 0
    for i in range(len(number)):
        if (i+1) % 2 == 0:
            sumEven += getDigits(int(number[int(i)]) * 2)
    return sumEven

# get the sum of digits in the odd places
def sumOfOddPlace(number):
    sumOdd = 0
    for i in range(len(number)):
        if (i+1) % 2 != 0:
            sumOdd += int(number[int(i)])
    return sumOdd

# check if a card number is valid
def isValid(n,number):
    if (sumOfDoubleEvenPlace(number) + sumOfOddPlace(number)) % 10 == 0 and checkConditions(n):
        return True
    else:
        return False


def main():
    if isValid(n,number):
        print('credit card numebr',n,'is valid.')
    else:
        print('credit card number',n,'is not valid.')

# call the function
main()
