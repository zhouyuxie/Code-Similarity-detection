# create a function to check whether a number is prime number 
def isPrime(n):
    divisor=2
    while divisor <= n/2:
        if n % divisor==0:
            return False
        else:
            divisor+=1
            continue
    return True

# create a function to check whether a number is palindromic
def isPalindromic(n):
    backward = int(str(n)[::-1])
    if n == backward:
        return True
    else:
        return False

# create a function to check whether a number is empirp or not, using isPrime and isPalindromic
def isEmirp(n):
    if isPrime(n) and not isPalindromic(n):
        backward = int(str(n)[::-1])
        if n != backward:
            return True
        else:
            return False
    else:
        return False     

#def main to print the first emirps in the required format
def main():
    count = 0
    n = 13
    while count < 100:
        if isEmirp(n):
            print("%7d"%n,end='')
            count += 1
            n += 1
        else:
            n += 1
            continue
        if count % 10 == 0:
            print()

#call the function
main()


