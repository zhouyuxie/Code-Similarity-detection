# First define a function to check whether a position is valid to insert a queen, then append valid queens to a list, and print(list).

import random

def isValid(Coordinate, Position): 
# To check whether the next queen is in the same diagonal or row or column with the former queen
    for i in range(len(Coordinate)): 
        #To check the coordinate of former queen and next queen
        if abs(Coordinate[i]-Position) in (0, len(Coordinate)-i):
            return False  
    return True

def insertQueen(space, queenList, Coordinate=()):
# Insert queens line by line
    for Position in range(space): 
        if isValid(Coordinate, Position):
            #To add the queen to the queenList and finish this line
            if len(Coordinate) == space-1: 
                queenList.append(Coordinate + (Position,))
            else:  # To find the next queen
                insertQueen(space, queenList, Coordinate+(Position,))

def output(answer):  # Print the queen of each line. Use 'Q' to represent queens on the chessboard and '_' to represent other positions on the chessboard
    for Position in answer:
        print('_  ' * (Position) + 'Q  ' + '_  '*(len(answer)-Position-1))

if __name__ == "__main__":
    queenList = []
    insertQueen(8, queenList) 
    output(random.choice(queenList))  # show one valid solution of Eight Queens