def isAnagram(s1, s2):#To check whether two words are consisted of same elements by checking whether they are same after being sorted. 
    if sorted(list(s1)) == sorted(list(s2)):#To sort the lists ang check if two lists identical
        print(s1.capitalize(), 'is an anagram of', s2 + '. ')
    else: 
        print(s1.capitalize(), 'is not an anagram of', s2 + '. ')

if __name__ == '__main__': 
    s1 = input('Enter the first word: ')
    s2 = input('Enter the second word: ')
    isAnagram(s1, s2)