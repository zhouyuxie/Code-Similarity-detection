def is_prime(m):#To tell whether a number is a prime
    for i in range(2, int(m ** 0.5 + 1)):
        if m % i == 0:
            return False
    return True

def is_emirp(n):#To tell whether a number is a emirp, a nonpalindromic prime number whose reversal is also a prime.
    N = n
    if is_prime(n) == True:
        reversal = int((str(n))[::-1])#To get reversal
        if N == reversal:
            return False
        else:
            if is_prime(reversal) == True:
                return True
            else:
                return False
    else:
        return False

def emirp_list():#To get the first 100 emirps list
    b = 13
    Elist = []
    while True:
        if is_emirp(b) == True:
            Elist.append(b)
        if len(Elist) == 100:
            break
        b += 1
    return Elist
    
if __name__ == '__main__':
    Elist = sorted(emirp_list())
    count = 0 
    for i in Elist:#To display 10 numbers per line and align the numbers properly
        print("%6d"%i, end = '')
        count += 1
        if count % 10 == 0:
            print()    