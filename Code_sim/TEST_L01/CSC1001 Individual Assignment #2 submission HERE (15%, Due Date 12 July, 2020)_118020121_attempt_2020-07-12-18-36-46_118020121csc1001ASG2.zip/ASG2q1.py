def sqrt(n):#to calculate the square root of the number user input(n)
    if n < 0:
        raise ValueError('illegal inputs')#Remind users of inputing wrong type
    elif n == 0:
        return 0
    else:
        lastGuess = 1
        nextGuess = (lastGuess + (n / lastGuess)) / 2
        ACC = 0.0001
        while abs(nextGuess - lastGuess) > ACC:
            lastGuess = nextGuess
            nextGuess = (lastGuess + (n / lastGuess)) / 2
        print('The approximated square root of', n, 'is', nextGuess, end = '. ')
