lockers = []
def initialLockers():# To get the initial 100 closed lockers
    for i in range(1,101):
        locker = [i , 0]
        global lockers
        lockers.append(locker)
    return lockers

def studenti():# To tell the change the ith student do
    for i in range(1, 101):
        for m in range(1, (100 // i + 1)):
            global lockers 
            lockers[i * m - 1][1] = not lockers[i * m - 1][1]
            
if __name__ == '__main__': 
    initialLockers()
    studenti()
    openLockers = []
    closedLockers = []
    for index in range(1,101): 
        if lockers[index - 1][1] == True: 
            openLockers.append(index)
        else: 
            closedLockers.append(index)
    print('These lockers are open: ') 
    print(openLockers)
    print('These lockers are closed: ') 
    print(closedLockers)

