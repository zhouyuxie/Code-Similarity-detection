def getDigit(digit): #To return the double of every second digit from right to left, and add up two digits of the result if the result is a twodigit number.
    sumDigit = digit * 2
    if sumDigit >= 10: 
        sumDigit = sumDigit%10 + 1
    return sumDigit


def sumOfDoubleEvenPlace(number): #To get the sum of the numbers returned by getDigit(number), and return the sum. The number is a string.
    List1 = (list(number))[::-1]
    sumDoubleEvenPlace = 0
    for digit in List1[1::2]: 
        sumDoubleEvenPlace = sumDoubleEvenPlace + getDigit(int(digit))
    return sumDoubleEvenPlace


def sumOfOddPlace(number): #To return the sum of odd place digits in the number. The number is a string.
    List2 = (list(number))[::-1]
    sumOddPlace = 0
    for digit in List2[::2]: 
        sumOddPlace = sumOddPlace + int(digit)
    return sumOddPlace


def isValid(number): # To tell whether the card is vaild and the type of the card
    start = number[0]
    length = len(number)
    if (start in ['4','5','6']) and (13 <= length <= 16):
        startwith = True
    elif (start == '3' and number[1] == '7') and (13 <= length <= 16): 
        startwith = True
    else: 
        startwith = False
    if startwith == True:# To make sure that the number follws the certain patterns
        Sum = sumOfDoubleEvenPlace(number) + sumOfOddPlace(number)
        if Sum % 10 == 0: 
            print('This credit card number is valid. ')
            cardDic = {'4':'Visa cards', '5':'MasterCard credit cards',
            '6':'Discover cards', '3':'American Express cards'}
            print('This card belongs to', cardDic[number[0]] + '. ')
        else: 
            print('This credit card number is invalid. ')
    else: 
        print('This credit card number is invalid. ')


if __name__ == '__main__':  
    number = input('Enter a credit card number: ')
    isValid(number)